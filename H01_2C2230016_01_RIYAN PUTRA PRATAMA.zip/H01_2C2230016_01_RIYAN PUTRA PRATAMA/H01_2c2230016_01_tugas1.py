# Nama : Riyan putra pratama
# NRP : 2C2230016
# Tanggal : 14 oktober 2024

#input harga barang
#A
harga_dasar_a = int(input("Masukkan harga dasar barang A : "))
harga_jual_a = int(input("Masukkan harga jual barang A   : "))

#B
harga_dasar_b = int(input("Masukkan harga dasar barang B : "))
harga_jual_b = int(input("Masukkan harga jual barang B   : "))

#c
harga_dasar_c = int(input("Masukkan harga dasar barang C : "))
harga_jual_c = int(input("Masukkan harga jual barang C   : "))

#menghitung keuntungan
keuntungan_a = (harga_jual_a - harga_dasar_a)
keuntungan_b = (harga_jual_b - harga_dasar_b)
keuntungan_c = (harga_jual_c - harga_dasar_c)

#mencari barang yang paling untung
if keuntungan_a > keuntungan_b and keuntungan_a > keuntungan_c:
    tawaran_barang = "A"
elif keuntungan_b > keuntungan_a and keuntungan_b > keuntungan_c:
    tawaran_barang = "B"
else:
    tawaran_barang = "C"

#input user
print(f"Barang yang harus di tawarkan adalah barang : ", tawaran_barang)