# Nama : Riyan putra pratama
# NRP : 2C2230016
# Tanggal : 14 oktober 2024



#mencari kelas berdasarkan akhiran nrp
def kelas_mahasiswa(akhiran_nrp):
 
#menentukan kelas berdasarkan rentang nrp
  if akhiran_nrp % 2 == 0:  # Jika nim genap
    if 1 <= akhiran_nrp <= 100:
      return "K2"
    elif 101 <= akhiran_nrp <= 200:
      return "K4"
    elif 201 <= akhiran_nrp <= 300:
      return "K6"
    else:
      return "K8"
  else:  # Jika nim ganjil
    if 1 <= akhiran_nrp <= 100:
      return "K1"
    elif 101 <= akhiran_nrp <= 200:
      return "K3"
    elif 201 <= akhiran_nrp <= 300:
      return "K5"
    else:
      return "K7"

#input user
nrp_input = int(input("Masukkan akhiran NRP: "))
kelas = kelas_mahasiswa(nrp_input)

print(f"Mahasiswa masuk ke kelas", kelas)